﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prueba_cifrado
{
    public partial class Descifrar : Form
    {
        public Descifrar()
        {
            InitializeComponent();
            InitializeComponent();
            

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            /* string result = string.Empty;
               //byte[] encryted = System.Text.Encoding.Unicode.GetBytes(txtcifrado.Text);
               //result = Convert.ToBase64String(encryted);
               // return result;
               int letras, t;
               string juntar = "";
               // string [] abecedario ={"a","b","c","d","e"};
               string Toriginal = txtcifrado.Text;
               letras = Toriginal.Length;
               char[] ch = new char[letras];
               for (int i = 0; i < letras; i = i + 1)
               {
                   t = (int)Toriginal[i];
                   ch[i] = (char)(t - 3);
                   juntar = juntar + ch[i];
               }
              lstdecifrado.Items.Add(juntar);*/
            Decifrar();
        }
        void Decifrar()
        {
            int letras, t;
            string juntar = "";           
            string cadena = txtCadena.Text;
            letras = cadena.Length;
            char[] ch = new char[letras];
            for (int i = 0; i < letras; i = i + 1)
            {
                t = (int)cadena[i];
                ch[i] = (char)(t - 3);
                juntar = juntar + ch[i];
            }
            lstdecifrado.Items.Add(juntar);
            MessageBox.Show("No entiendo");
        }
        void lim()
        {
            lstdecifrado.Items.Clear();
        }
    }
}
