﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prueba_cifrado
{
    public partial class Cifrar : Form
    {
        public Cifrar()
        {
            InitializeComponent();
            InitializeComponent();
            Bitmap img = new Bitmap(Application.StartupPath + @"\Img\Encriptar.jpg");
            this.BackgroundImage = img;
            this.BackgroundImageLayout = ImageLayout.Stretch;
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int letras, t;
            string juntar="";
           // string [] abecedario ={"a","b","c","d","e"};
            string Toriginal = txtoriginal.Text;
            letras = Toriginal.Length;
            char[] ch = new char[letras];
            for (int i = 0; i < letras; i = i + 1)
            {
                t = (int)Toriginal[i];
                ch[i] = (char)(t + 3);
                juntar = juntar + ch[i];
                
            }
            lstcifrado.Items.Add(juntar);
            






        }
    }
}
